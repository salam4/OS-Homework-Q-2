/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package findprimenumbers;
import java.util.Scanner;
/**
 *
 * @author Saqeb Alam
 * Implementing different threads on finding the prime integer that is less
 * than the user entered integer
 */
public class FindPrimeNumbers {

    public static void main(String[] args) {
           //get integer from user
        System.out.println("Enter a Integer: ");
        Scanner skey = new Scanner(System.in);
        //save integer
        int num = skey.nextInt();
        
        //start of threading
        PrimeSavingThread pst_1 = new PrimeSavingThread (num);
        //using the thread methid
        pst_1.start();
        
        //yield() basically means that the thread is not doing anything particularly important and 
        //if any other threads or processes need to be run, they should run. 
        //Otherwise, the current thread will continue to run.
        Thread.yield();
//seperate thread on finding all numbers less than input
        pst_1.AllPrimeNumber();
    }
    
}
class PrimeSavingThread extends Thread {
     private final int given_number;
//calls java thread method
    PrimeSavingThread (int n) {
        given_number = n;
    }
    
    //going through all numbers that can be prime
public void AllPrimeNumber() {
    // declaring and initializing array
     int[] number = null;
     System.out.println("Here are all the Prime Number less than or equal to "+given_number);
     //starting from integer down to zero
    for (int i = given_number; i >= 0; i--) {
        // calling another method on checking if it is a prime number
        if (PrimeValidation(i)) {
            //printing if true
            System.out.println(i);
        }
    }
}

//prime checking
public static boolean PrimeValidation (int n) {
        for (int i=2 ; i<n ; i++) {
            if (n%i == 0)
                return false;
        }
        return true;
    }
}